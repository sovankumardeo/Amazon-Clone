alter table "public"."profiles" add column "expo_push_token" text;


