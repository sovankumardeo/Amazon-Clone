alter table "public"."profiles" add column "stripe_customer_id" text;


